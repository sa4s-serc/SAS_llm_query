import os
from typing import List, Dict

from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage, SystemMessage
from dotenv import load_dotenv

# Load environment variables from a .env file if present
load_dotenv()

# Ensure that the OpenAI API key is set
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPEN_AI_MODEL = os.getenv("OPEN_AI_MODEL")
if not OPENAI_API_KEY:
    raise ValueError("Please set the OPENAI_API_KEY environment variable.")
if not OPEN_AI_MODEL:
    raise ValueError("Please set the OPEN_AI_MODEL environment variable.")

# Define the path to the microservices file
MICROSERVICES_FILE = "microservices.txt"

def load_microservices(file_path: str) -> List[Dict[str, str]]:
    """
    Reads the microservices from a text file and returns a list of dictionaries.
    Each dictionary contains 'name' and 'description' of a microservice.
    """
    microservices = []
    with open(file_path, "r") as f:
        for line in f:
            # Skip empty lines
            if not line.strip():
                continue
            try:
                name, description = line.strip().split(",", 1)
                microservices.append({"name": name.strip(), "description": description.strip()})
            except ValueError:
                print(f"Skipping invalid line: {line.strip()}")
    return microservices

def prepare_microservices_prompt(microservices: List[Dict[str, str]]) -> str:
    """
    Prepares a formatted string of microservices to include in the prompt.
    """
    prompt = "Here is a list of available microservices:\n"
    for ms in microservices:
        prompt += f"- {ms['name']}: {ms['description']}\n"
    return prompt

def identify_microservices(conversation: List[str], microservices: List[Dict[str, str]]) -> List[str]:
    """
    Uses the LLM to identify relevant microservices based on the conversation.
    """
    microservices_prompt = prepare_microservices_prompt(microservices)
    
    identification_prompt = (
        "Based on the following conversation between a user and an assistant, identify which of the available microservices are required to fulfill the user's goals.\n\n"
        "Conversation:\n"
    )
    
    # Combine the conversation into a single string
    for turn in conversation:
        identification_prompt += f"{turn}\n"
    
    identification_prompt += f"\n{microservices_prompt}\n"
    identification_prompt += "List the relevant microservices separated by commas."

    # Initialize the ChatOpenAI LLM
    llm = ChatOpenAI(openai_api_key=OPENAI_API_KEY, temperature=0.7, model_name=OPEN_AI_MODEL)

    # Get the response from the LLM
    response = llm([HumanMessage(content=identification_prompt)])

    # Process the response to extract microservice names
    identified = [ms.strip() for ms in response.content.split(",") if ms.strip()]
    return identified



def main():
    # Load microservices
    microservices = load_microservices(MICROSERVICES_FILE)
    if not microservices:
        print("No microservices found. Please check the microservices.txt file.")
        return

    # Initialize the ChatOpenAI LLM
    llm = ChatOpenAI(openai_api_key=OPENAI_API_KEY, temperature=0.7, model_name=OPEN_AI_MODEL)

    conversation_history = []
    
    system_prompt = (
        f"""You are an intelligent assistant designed to help users with various tasks and queries. 
        Engage in a natural, friendly conversation, as if you were a helpful friend or colleague.
        Provide assistance and information based on your knowledge, without explicitly mentioning any limitations.
        If you can't directly provide specific real-time data, guide the user towards how they might find that information themselves.
        If the user's request relates to any of the available microservices, subtly guide the conversation in that direction without explicitly mentioning microservices. 
        Always remember the context of the entire conversation and use it to provide relevant and helpful responses.
        The microservices available to you are {microservices}.
        Maintain a conversational tone throughout the interaction, avoiding any robotic or overly formal language.
        After 3 user inputs, you will need to summarize what the user is looking for. Do not ask additional questions at this point.
        """
    )
    conversation_history.append(SystemMessage(content=system_prompt))

    print("\n"*5)
    prompt_count = 0
    while True:
        # Get the assistant's response
        assistant_messages = conversation_history + [HumanMessage(content="Assistant:")]
        assistant_response = llm(assistant_messages)
        print(f"Assistant: {assistant_response.content}")

        # Append assistant's response to the conversation history
        conversation_history.append(assistant_response)

        # Get user input
        user_input = input("You: ").strip()
        if user_input.lower() in {"exit", "quit", "bye", "goodbye"}:
            print("It was great chatting with you! Take care and have a wonderful day!")
            return  # Exit without identifying microservices if user explicitly ends the conversation

        if not user_input:
            print("Sorry, I didn't catch that. Mind repeating?")
            continue

        # Append user input to the conversation history
        conversation_history.append(HumanMessage(content=user_input))

        prompt_count += 1

        # Identify and print relevant microservices after each prompt
        identified_services = identify_microservices([msg.content for msg in conversation_history], microservices)
        print("\n(not llm): Identified services so far- ", ", ".join(identified_services) if identified_services else "None")

        # After 3 prompts, summarize and ask for confirmation
        if prompt_count == 3:
            summary_prompt = (
                "Based on the conversation so far, please provide a brief summary of what the user is looking for. "
                "Start with 'It looks like you're looking to...' and keep it concise and in a natural, conversational tone. "
                "Do not ask any additional questions."
            )
            summary_response = llm(conversation_history + [HumanMessage(content=summary_prompt)])
            print(f"\nAssistant: {summary_response.content} Is that right?")

            user_confirmation = input("You (yes/no): ").strip().lower()
            if user_confirmation in ['yes', 'y']:
                print("Great! I think I have a good understanding of what you need.")
                break
            else:
                print("I see. Let's continue our chat so I can better understand what you're looking for.")
                prompt_count = 0  # Reset the count to continue the conversation
                continue

    # Final identification of relevant microservices based on the entire conversation
    final_identified_microservices = identify_microservices([msg.content for msg in conversation_history], microservices)

    if final_identified_microservices:
        print("\nBased on our chat, I think these might be helpful for you:")
        for ms in final_identified_microservices:
            print(f"- {ms}")
    else:
        print("\nThanks for the great conversation! If you ever need any specific help, just give me a shout.")

if __name__ == "__main__":
    main()