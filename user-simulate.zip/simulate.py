import os
from typing import List, Dict
from dotenv import load_dotenv
from crewai import Agent, Task, Crew
from langchain_openai import ChatOpenAI
from utils import load_microservices, get_user_goal

# Load environment variables
load_dotenv()
max_turns = 4  # 3 regular turns + 1 summary turn

# Ensure that the OpenAI API key is set
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPEN_AI_MODEL = os.getenv("OPEN_AI_MODEL")

if not OPENAI_API_KEY:
    raise ValueError("Please set the OPENAI_API_KEY environment variable.")
if not OPEN_AI_MODEL:
    raise ValueError("Please set the OPEN_AI_MODEL environment variable.")

# Set up the OpenAI model
llm = ChatOpenAI(
    openai_api_key=OPENAI_API_KEY,
    model_name=OPEN_AI_MODEL,
    temperature=0.7
)



MICROSERVICES_FILE = "microservices.txt"
microservices = load_microservices(MICROSERVICES_FILE)



def prepare_microservices_prompt(microservices: List[Dict[str, str]]) -> str:
    prompt = "Available microservices:\n"
    for ms in microservices:
        prompt += f"- {ms['name']}: {ms['description']}\n"
    return prompt

microservices_prompt = prepare_microservices_prompt(microservices)

# Define the agents
user_goal = get_user_goal()
user_agent = Agent(
    role="Smart City Event Visitor",
    goal=f"To : {user_goal}",
    backstory=f"You are a visitor to a smart city event, looking for a workspace that meets your specific requirements. {user_goal}",
    llm=llm
)

chatbot_agent = Agent(
    role="Smart City Event Assistant",
    goal="To assist visitors in finding suitable workspaces and identify relevant microservices",
    backstory=f"You are an AI assistant at a smart city event, helping visitors find workspaces and identifying which microservices are relevant to their needs. You can only provide information based on the following microservices:\n{microservices_prompt}\nDo not offer to check real-time availability or access information you don't have.",
    llm=llm
)

def create_conversation_task(agent, turn_number, is_user=False):
    if is_user:
        description = f"As a visitor, engage in turn {turn_number} out of {max_turns} of the conversation. Ask about your workspace needs or respond to the assistant's questions. Your goal is: {user_goal}. Do ensure not to deviate alot from it in conversations"
    else:
        description = f"As the assistant, engage in turn {turn_number} out of {max_turns} of the conversation. Respond to the visitor's questions or ask for more information. Only provide information based on the available microservices. Do not offer to check real-time availability or access information you don't have."
    
    return Task(
        description=description,
        agent=agent,
        expected_output="A response that continues the conversation naturally, asking questions or sharing relevant information based only on available microservices."
    )

# Create tasks for the conversation
tasks = []
for turn in range(max_turns * 2):  # Total turns will be max_turns * 2
    current_agent = user_agent if turn % 2 == 0 else chatbot_agent
    is_user = turn % 2 == 0
    task = create_conversation_task(current_agent, turn + 1, is_user)
    tasks.append(task)

# Add the final summary task
tasks.append(Task(
    description="Summarize the visitor's needs based on the conversation. Start with 'It looks like you're looking to...' and keep it concise and in a natural, conversational tone. Do not offer to check availability or provide specific room information.",
    agent=chatbot_agent,
    expected_output="A summary of the visitor's needs in a natural, conversational tone."
))

# Add the final identification task
tasks.append(Task(
    description=f"Based on the entire conversation and the summary of the visitor's needs, identify the relevant microservices that would meet the visitor's needs. Only list microservices from the following list:\n{microservices_prompt}\nProvide the names of the relevant microservices, separated by commas.",
    agent=chatbot_agent,
    expected_output="A comma-separated list of relevant microservice names from the provided list."
))

# Create the crew with all tasks
conversation_crew = Crew(
    agents=[user_agent, chatbot_agent],
    tasks=tasks,
    verbose=True
)

# Run the conversation
result = conversation_crew.kickoff()

print("\nFull conversation:")
for task in tasks[:-2]:  # Exclude the last two tasks (summary and identification tasks)
    print(f"\n{task.agent.role}:")
    print(task.output.raw if task.output else "No output")

print("\nSummary of visitor's needs:")
print(tasks[-2].output.raw if tasks[-2].output else "No summary provided")

print("\nIdentified Microservices:")
print(tasks[-1].output.raw if tasks[-1].output else "No microservices identified")

print("\nFinal result:")
print(result)