import random
from typing import List, Dict


def get_user_goal() -> str:
    user_prompts = [
        "I need a quiet workspace to concentrate on my project.",
        "Can you help me find a space with strong Wi-Fi and multiple charging stations?",
        "I'm looking to book a collaborative area with large displays for team meetings.",
        "I prefer a comfortable temperature and natural light to stay inspired.",
        "I need a workspace immediately that has access to interactive displays and fast internet."
    ]
    return random.choice(user_prompts)
# Load microservices
def load_microservices(file_path: str) -> List[Dict[str, str]]:
    microservices = []
    with open(file_path, "r") as f:
        for line in f:
            if line.strip():
                try:
                    name, description = line.strip().split(",", 1)
                    microservices.append({"name": name.strip(), "description": description.strip()})
                except ValueError:
                    print(f"Skipping invalid line: {line.strip()}")
    return microservices